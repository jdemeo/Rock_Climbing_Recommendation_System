import pandas as pd
import numpy as np

# vectorized haversine function
def haversine(lat1, lon1, lat2, lon2, to_radians=True, earth_radius=6371):
    """
    slightly modified version: of http://stackoverflow.com/a/29546836/2901002

    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees or in radians)

    All (lat, lon) coordinates must have numeric dtypes and be of equal length.
    """
    if to_radians:
        lat1, lon1, lat2, lon2 = np.radians([lat1, lon1, lat2, lon2])

    a = np.sin((lat2-lat1)/2.0)**2 + \
        np.cos(lat1) * np.cos(lat2) * np.sin((lon2-lon1)/2.0)**2

    return earth_radius * 2 * np.arcsin(np.sqrt(a))

# Get all user_ids and route_ids
with open('users.txt', 'r') as f:
    user_ids = f.read().splitlines()
with open('routes.txt', 'r') as f:
    route_ids = f.read().splitlines()

# Load in latent matrices and biases
U = np.load('U.npy')
Vt = np.load('Vt.npy')
b_u = np.load('b_u.npy')
b_i = np.load('b_i.npy')
mu = 2.7401829352698774

# Load in original user, route, rating matrix
df = pd.read_csv('user_routes_reduced.csv')

# Load in route lat long
lat_long_df = pd.read_csv('master_routes_lat_long.csv')


# Input userID
cur_user = '107153125'
cur_user_index = user_ids.index(cur_user)

# Make prediction given a user
user_predicted_ratings = np.dot(U[cur_user_index], Vt) + b_u[cur_user_index] + b_i + mu

# User collected data
user_lat = 40.7564
user_long = -111.8986
max_distance = 25

# Get list of routes that are within certain distance
available_routes = df['RouteID'].unique().astype(str)

# Subset data
available_routes_lat_long = lat_long_df[lat_long_df['RouteID'].isin(available_routes)].reset_index(drop=True)
close_routes = []

# Calculate distances from user
for i in range(len(available_routes_lat_long)):
    route_id = available_routes_lat_long.loc[i, 'RouteID'].astype(str)
    distance = haversine(user_lat,
                         user_long,
                         available_routes_lat_long.loc[i, 'Latitude'],
                         available_routes_lat_long.loc[i, 'Longitude'])
    # Keep routes less than particular distance
    if distance <= max_distance:
        close_routes.append(str(route_id))

print("Number of close routes:", len(close_routes))

# Keep routes only in proximity to specified location and drop routes the user has already done
completed_routes = df.loc[df['UserID'] == int(cur_user), 'RouteID'].astype(str)
routes_of_interest = [route for route in close_routes if route not in completed_routes]
roi_indices = [route_ids.index(route) for route in routes_of_interest]

reduced_Vt = Vt[:,roi_indices]
reduced_b_i = b_i[roi_indices]

# Create prediction vector
user_predicted_ratings = np.dot(U[cur_user_index], reduced_Vt) + b_u[cur_user_index] + reduced_b_i + mu

# Get indices sort to corresponding highest to lowest values in array
sorted_ind = np.argsort(user_predicted_ratings)[::-1]   # [::-1] reverse order so it's highest to lowest

# Collect top k-values
k = 5
k_ind = sorted_ind[:k]
top_k_ratings = user_predicted_ratings[k_ind]
top_k_routes = [routes_of_interest[index] for index in k_ind]
print("Recommendations:")
for i in range(k):
    print('Route:', top_k_routes[i])
    print('Rating:', top_k_ratings[i])
